#!/usr/bin/env python3
"""Focused BUG-121 replacement adapter; parent review is required before running."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import sys
import time
from pathlib import Path


ROOT = next(p for p in Path(__file__).resolve().parents if (p / "scripts/build.sh").is_file())
SCRATCH = Path(__file__).resolve().parent
BUILD = Path(os.environ.get("LADYBUG_TEST_BUILD", str(ROOT / "build"))).resolve()
DELIVERY_DIR = ROOT / "repro/bugpass-20261010/luna122-qa-plan"
LEGACY_DIR = ROOT / "repro/bugpass-20261010"
PAGE34 = 0x34 * 8192
DIR_STEP = (-320, 1, 320, -1)
DIR_CELL = ((0, -1), (1, 0), (0, 1), (-1, 0))
ENTRY_MASK = (0x04, 0x08, 0x01, 0x02)
FROZEN = {
    "repro/bugpass-20261010/verify_movement.py":
        "9f6512be48d9b001bf1f4282a26e003062c38770e8589d6deb0ecc4930fd0d3a",
    "repro/bugpass-20261010/luna122-qa-plan/runtime.py":
        "d77b1d2225829b445728396a2068c45cd1b350cbcfb4cbf914924eb3b172fd80",
    "repro/bugpass-20261010/luna122-qa-plan/verify_bug122.py":
        "9df2162753ed528993b426af50be74ab866514666b0c08325dfe530eed3ea066",
    "repro/bugpass-20261010/luna122-qa-plan/pixel_oracle.py":
        "4839d0d0db7f0058de152e8fc38ebb2395716b7d81f538803683b56f42217497",
    "scripts/verify_bug011_runtime.py":
        "a12b6569112f4393c304b0fb976d9f88d92eea8c923ff5679e155b01773a9b92",
    "scripts/verify_bug009_monitor_input.py":
        "e852eec0a6d20cdd13d8c05ae10c2a136d5cab3cb17243e552e85b31da158c70",
}

CORNER_CASES = (
    ("N>E", (6, 3), (6, 2), 0, 1, 0x0E, 0x00, 0x0A),
    ("S>W", (6, 5), (6, 6), 2, 3, 0x0F, 0x00, 0x0A),
    ("E>S", (5, 4), (6, 4), 1, 2, 0x0D, 0x00, 0x05),
    ("W>N", (9, 4), (8, 4), 3, 0, 0x07, 0x00, 0x05),
)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def check_frozen_inputs() -> dict[str, str]:
    found = {}
    for rel, expected in FROZEN.items():
        actual = digest((ROOT / rel).read_bytes())
        if len(expected) != 64:
            raise AssertionError(f"frozen SHA-256 must be 64 hex digits: {rel}")
        if actual != expected:
            raise AssertionError(f"frozen dependency changed: {rel} {actual} != {expected}")
        found[rel] = actual
    return found


def load_shared_modules():
    sys.path.insert(0, str(DELIVERY_DIR))
    import verify_bug122 as delivery

    rt = delivery.load_runtime(BUILD)
    original_receipt = rt.receipt
    rt.receipt = lambda *args, **kwargs: None
    try:
        sys.path.insert(1, str(LEGACY_DIR))
        path = LEGACY_DIR / "verify_movement.py"
        spec = importlib.util.spec_from_file_location("bug121_existing_movement", path)
        legacy = importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(legacy)
    finally:
        rt.receipt = original_receipt
    return delivery, rt, legacy


def resident_symbol(q, rt, name: str, length: int) -> bytes:
    address = q.ms.get(name)
    resident = (BUILD / "ladybug-runtime.rom").read_bytes()[:0x3E00]
    if address is None or not 0xC000 <= address or address + length > 0xC000 + len(resident):
        raise AssertionError(f"{name}={address!r} is outside qualified resident bytes")
    offset = address - 0xC000
    expected = resident[offset:offset + length]
    physical = q.phys(0x3E * 8192 + offset, length)
    logical = rt.r.read_bytes(q.c, address, length)
    if len(expected) != length or physical != expected or logical != expected:
        raise AssertionError(f"{name} authored-map/staged/live identity differs")
    return expected


def qualified_tables(q, rt) -> tuple[bytes, bytes, bytes]:
    nav = resident_symbol(q, rt, "maze_nav", 576)
    owners = resident_symbol(q, rt, "maze_gate_owner", 576)
    gates = resident_symbol(q, rt, "maze_gates", 60)
    for name, current, next_cell, old, want, next_mask, current_target, next_target in CORNER_CASES:
        cx, cy = current
        nx, ny = next_cell
        ni = ny * 24 + nx
        ci = cy * 24 + cx
        wx, wy = DIR_CELL[want]
        if nav[ni] != next_mask or nav[ci + wy * 24 + wx] != current_target:
            raise AssertionError(f"{name}: byte-backed corner masks differ from approved fixture")
        if nav[ni + wy * 24 + wx] != next_target or not nav[ni] & ENTRY_MASK[old]:
            raise AssertionError(f"{name}: upcoming approach/exit is not byte-backed")
        destinations = (
            ("forward", nx, ny),
            ("current-request", cx + wx, cy + wy),
            ("upcoming-turn", nx + wx, ny + wy),
        )
        for role, x, y in destinations:
            owner = owners[y * 24 + x]
            if owner != 0:
                raise AssertionError(
                    f"{name}: {role} destination ({x},{y}) has gate owner {owner}")
    no_exit = (((12, 16), 0, 3, (12, 15), (11, 16), (11, 15)),
               ((12, 15), 2, 1, (12, 16), (13, 15), (13, 16)))
    for current, old, want, next_cell, cur_target, next_target in no_exit:
        cx, cy = current
        nx, ny = next_cell
        if nav[cy * 24 + cx] != 0x05 or nav[ny * 24 + nx] != 0x05:
            raise AssertionError(f"no-exit {(current, old, want)} corridor masks changed")
        if nav[cur_target[1] * 24 + cur_target[0]] or nav[next_target[1] * 24 + next_target[0]]:
            raise AssertionError(f"no-exit {(current, old, want)} target unexpectedly opens")
    if nav[2 * 24 + 3] != 0x0A or nav[3 * 24 + 3] != 0:
        raise AssertionError("gate fixture current (3,2) / rejected request (3,3) masks changed")
    if nav[3 * 24 + 4] != 0x15 or owners[3 * 24 + 4] != 1 or gates[:3] != bytes((5, 3, 0)):
        raise AssertionError("gate-0 endpoint fixture differs from approved bytes")
    return nav, owners, gates


def record_source_and_artifacts() -> dict[str, object]:
    source = {rel: digest((ROOT / rel).read_bytes())
              for rel in ("src/main.s", "src/enemy_runtime.s")}
    artifacts = {name: digest((BUILD / name).read_bytes())
                 for name in ("ladybug.rom", "ladybug-runtime.rom", "ladybug.map")}
    receipt = BUILD / "source-build-receipt.json"
    if receipt.is_file():
        artifacts["source-build-receipt.json"] = digest(receipt.read_bytes())
    return {"source_sha256_at_run": source, "build_artifact_sha256": artifacts}


def prove_marker(q, rt, marker_counts: dict[str, object], name: str) -> None:
    if name not in ("player_tick", "pt_done"):
        return
    address = q.ms.get(name)
    regs = q.c.call("read_registers")
    if address is None or regs.get("pc") != address:
        raise AssertionError(f"{name}: live PC {regs.get('pc')!r} differs from map {address!r}")
    if not 0xC000 <= address < 0xFE00:
        raise AssertionError(f"{name}: address {address:04X} is outside resident proof span")
    slot = address >> 13
    raw_page = rt.r.read_bytes(q.c, 0xFFA0 + slot, 1)[0]
    page = raw_page & 0x3F
    expected_page = 0x3E if slot == 6 else 0x3F if slot == 7 else -1
    if page != expected_page or (address & 0x1FFF) + 16 > 8192:
        raise AssertionError(f"{name}: PAR slot {slot} maps {page:02X}, expected {expected_page:02X}")
    resident = (BUILD / "ladybug-runtime.rom").read_bytes()[:0x3E00]
    offset = address - 0xC000
    expected = resident[offset:offset + 16]
    physical = page * 8192 + (address & 0x1FFF)
    live_physical = q.phys(physical, 16)
    live_logical = rt.r.read_bytes(q.c, address, 16)
    if len(expected) != 16 or live_physical != expected or live_logical != expected:
        raise AssertionError(f"{name}: staged/logical/PAR-selected physical bytes differ")
    entry = marker_counts.setdefault(name, {"count": 0, "address": address,
                                             "page": page, "bytes_sha256": digest(expected)})
    entry["count"] += 1
    entry["last_pc"] = regs["pc"]
    entry["last_par_raw"] = raw_page


def track_player_markers(q, rt, report: dict[str, object]) -> None:
    counts: dict[str, object] = {}
    original_go = q.go

    def tracked(label="mainloop"):
        prior_deadline = q.phase_deadline
        scenario_deadline = getattr(q, "scenario_deadline", None)
        if scenario_deadline is not None:
            q.phase_deadline = min(prior_deadline, scenario_deadline) if prior_deadline else scenario_deadline
        try:
            original_go(label)
        finally:
            q.phase_deadline = prior_deadline
        prove_marker(q, rt, counts, label)

    q.go = tracked
    report["player_marker_proofs"] = counts


def begin_scenario(q, report: dict[str, object], label: str) -> None:
    report["phase"] = label
    q.current_scenario = label
    q.scenario_deadline = time.monotonic() + 45


def page34_snapshot(q, delivery, rt) -> dict[str, object]:
    maze, proof = delivery.qualified_maze_snapshot(q, "BUG-121 route fixture")
    par5 = rt.r.read_bytes(q.c, 0xFFA5, 1)[0]
    count, entities = delivery.direct_table(q)
    logical_entities = rt.r.read_bytes(q.c, 0xA380, len(entities))
    if q.ms.get("ENTITY_TABLE") != 0xA380 or (par5 & 0x3F) != 0x34 or logical_entities != entities:
        raise AssertionError("entity table is not qualified at logical $A380 / physical page $34")
    if q.ms.get("ENEMY_TABLE") != 0xA470:
        raise AssertionError("ENEMY_TABLE map address changed from $A470")
    enemies = q.phys(PAGE34 + 0x470, 32)
    if rt.r.read_bytes(q.c, 0xA470, 32) != enemies:
        raise AssertionError("logical $A470 enemy table differs from physical page-$34")
    return {"maze": bytearray(maze), "entities": bytearray(entities), "entity_count": count,
            "enemies": enemies, "PAR5_raw": par5, "maze_proof": proof}


def isolate_route(q, delivery, rt, cells: set[tuple[int, int]], label: str) -> dict[str, object]:
    if q.val("DEATH_STATE") or q.val("PICKUP_TIMER"):
        raise AssertionError(f"{label}: natural pre-fixture death/pickup state is nonzero")
    state = page34_snapshot(q, delivery, rt)
    changed_dots = []
    for x, y in sorted(cells):
        index = y * 24 + x
        if state["maze"][index] & 0x80:
            changed_dots.append({"cell": [x, y], "before": state["maze"][index]})
    changed_entities = []
    for i in range(state["entity_count"]):
        record = state["entities"][4 * i:4 * i + 4]
        if record[2] and (record[0], record[1]) in cells:
            changed_entities.append({"slot": i, "cell": list(record[:2]),
                                     "type": record[2], "bonus_counted": record[2] != 1})
    dots_before = q.val("DOTS_LEFT")
    bonuses_before = q.val("BONUS_LEFT")
    bonus_removed = sum(row["bonus_counted"] for row in changed_entities)
    if dots_before <= len(changed_dots) or bonuses_before <= bonus_removed:
        raise AssertionError(f"{label}: fixture would exhaust a stage counter")
    for row in changed_dots:
        x, y = row["cell"]
        q.put(PAGE34 + y * 24 + x, [row["before"] & 0x7F])
    for row in changed_entities:
        q.put(PAGE34 + 0x380 + 4 * row["slot"] + 2, [0])
    if changed_dots:
        q.dp("DOTS_LEFT", [dots_before - len(changed_dots)])
    if bonus_removed:
        q.dp("BONUS_LEFT", [bonuses_before - bonus_removed])
    enemy_rows = []
    for i in range(4):
        record = state["enemies"][8 * i:8 * i + 8]
        if record[0]:
            x, y = record[4], record[5]
            clearance = min(max(abs(x - cx), abs(y - cy)) for cx, cy in cells)
            enemy_rows.append({"slot": i, "cell": [x, y], "chebyshev_clearance": clearance})
            if clearance <= 1:
                raise AssertionError(f"{label}: active enemy enters player contact zone: {enemy_rows[-1]}")
    after, maze_proof = delivery.qualified_maze_snapshot(q, label + " after fixture")
    _, entity_after = delivery.direct_table(q)
    if rt.r.read_bytes(q.c, 0xA380, len(entity_after)) != entity_after:
        raise AssertionError(f"{label}: entity logical/physical identity failed after fixture")
    for x, y in cells:
        if after[y * 24 + x] & 0x80:
            raise AssertionError(f"{label}: route still contains a consumable dot at {(x, y)}")
    return {"label": label, "route_cells": [list(c) for c in sorted(cells)],
            "cleared_dot_bits": changed_dots, "disabled_route_entities": changed_entities,
            "DOTS_LEFT": [dots_before, q.val("DOTS_LEFT")],
            "BONUS_LEFT": [bonuses_before, q.val("BONUS_LEFT")],
            "active_enemy_clearance": enemy_rows, "maze_mapping_proof": maze_proof}


def center_fb(x: int, y: int) -> int:
    return 0x2000 + (y * 8 - 7) * 160 + (x * 4 + 28)


def pose_sample(q) -> dict[str, object]:
    return {"pose": q.pose(), "direction": q.val("PLAYER_DIR"),
            "want": q.val("PLAYER_WANT"), "face": q.val("PLAYER_FACE"),
            "snap": q.val("TURN_SNAP"), "death": q.val("DEATH_STATE"),
            "pickup_timer": q.val("PICKUP_TIMER")}


def settle_input(q, label: str) -> None:
    q.key(None)
    q.wait(lambda: q.val("JOY_DIR") == 0xFF and q.val("FB_RENDER_PENDING") == 0,
            label + " neutral and framebuffer idle")


def assert_pose(actual: dict[str, object], expected: list[int], label: str) -> None:
    if actual["pose"] != expected:
        raise AssertionError(f"{label}: pose {actual['pose']} != {expected}")
    if actual["death"] or actual["pickup_timer"]:
        raise AssertionError(f"{label}: unexpected death/pickup effects: {actual}")


def test_natural_movement(q, tables, report) -> dict[str, object]:
    nav, owners, _ = tables
    begin_scenario(q, report, "natural real-input movement")
    x, y, step, fb = q.pose()  # q.start leaves the qualified natural mainloop stopped.
    if not 0 <= x < 24 or not 0 <= y < 24 or step > 3:
        raise AssertionError(f"natural mainloop pose is outside the maze: {q.pose()}")
    current_dir = q.val("PLAYER_DIR")
    if step:
        direction = current_dir if current_dir in range(4) else None
    else:
        direction = None
        for d in range(4):
            dx, dy = DIR_CELL[d]
            nx, ny = x + dx, y + dy
            if (0 <= nx < 24 and 0 <= ny < 24 and
                    nav[ny * 24 + nx] & ENTRY_MASK[d] and owners[ny * 24 + nx] == 0):
                direction = d
                break
    if direction is None:
        raise AssertionError(f"natural player at {(x, y)} has no regular open exit")
    q.input_entry(direction)
    before = pose_sample(q)  # actual state at player_tick after real input was latched.
    bx, by, bstep, bfb = before["pose"]
    if bstep and before["direction"] != direction:
        raise AssertionError(f"natural route changed direction before its observed player_tick: {before}")
    if not bstep:
        dx, dy = DIR_CELL[direction]
        tx, ty = bx + dx, by + dy
        if not (0 <= tx < 24 and 0 <= ty < 24 and
                nav[ty * 24 + tx] & ENTRY_MASK[direction] and owners[ty * 24 + tx] == 0):
            raise AssertionError(f"natural centered route is no longer an open ordinary exit: {before}")
    q.go("pt_done")
    after = pose_sample(q)
    if bstep == 3:
        dx, dy = DIR_CELL[direction]
        expected = [bx + dx, by + dy, 0, bfb + DIR_STEP[direction]]
    else:
        expected = [bx, by, bstep + 1, bfb + DIR_STEP[direction]]
    assert_pose(after, expected, "natural mapped-input movement")
    if after["direction"] != direction or after["want"] != direction:
        raise AssertionError(f"natural input did not control movement: {after}")
    return {"direction": direction, "natural_mainloop_pose": [x, y, step, fb],
            "before_player_tick": before, "after": after["pose"],
            "natural_cold_start": True}


def test_missing_no_exit_offsets(q, delivery, rt, fixtures, report) -> list[dict[str, object]]:
    results = []
    for step in (1, 2):
        begin_scenario(q, report, f"no-exit S>E step {step}")
        settle_input(q, f"no-exit S>E step {step}")
        q.input_entry(1)
        cells = {(12, 15), (12, 16), (13, 15), (13, 16)}
        fixture = isolate_route(q, delivery, rt, cells, f"no-exit-S-E-{step}")
        q.fixture(12, 15, 2, step)
        if q.val("PLAYER_WANT") != 1 or q.val("JOY_DIR") != 1:
            raise AssertionError("real east input was not retained at player_tick")
        before = pose_sample(q)
        q.go("pt_done")
        after = pose_sample(q)
        assert_pose(after, before["pose"], f"no-exit S>E step {step}")
        if after["face"] != 1 or after["snap"] != 0:
            raise AssertionError(f"no-exit S>E changed facing/snap incorrectly: {after}")
        fixtures.append(fixture)
        results.append({"step": step, "pose": after["pose"], "face": after["face"],
                        "risk": "upcoming no-exit must hold at early partial offsets"})
    return results


def test_mapped_midcorridor_reversal(q, delivery, rt, fixtures, report) -> dict[str, object]:
    begin_scenario(q, report, "mapped-input midcorridor reversal")
    settle_input(q, "midcorridor reversal")
    q.input_entry(2)
    fixture = isolate_route(q, delivery, rt, {(12, 16), (12, 15)}, "midcorridor-reversal-N-to-S")
    q.fixture(12, 16, 0, 2)
    if q.val("JOY_DIR") != 2 or q.val("PLAYER_WANT") != 2:
        raise AssertionError("real south input was not retained for the reversal")
    before = pose_sample(q)
    if before["pose"][:3] != [12, 16, 2] or before["direction"] != 0:
        raise AssertionError(f"reversal fixture did not begin at the qualified northward half-step: {before}")
    q.go("pt_done")
    after = pose_sample(q)
    expected = [12, 15, 3, before["pose"][3] + DIR_STEP[2]]
    assert_pose(after, expected, "mapped-input midcorridor reversal")
    if after["direction"] != 2 or after["face"] != 2 or after["snap"] != 0:
        raise AssertionError(f"reversal did not follow pt_rebase_north/pt_reversed: {after}")
    fixtures.append(fixture)
    return {"input": "mapped South", "before_player_tick": before,
            "after": after, "expected": expected,
            "source_path": "pt_rebase_north -> pt_reversed -> pt_advance"}


def test_upcoming_corners(q, delivery, rt, tables, fixtures, report) -> list[dict[str, object]]:
    results = []
    for name, current, next_cell, old, want, _, _, _ in CORNER_CASES:
        cx, cy = current
        nx, ny = next_cell
        wx, wy = DIR_CELL[want]
        route = {current, next_cell, (nx + wx, ny + wy)}
        for initial_step in (1, 2, 3):
            begin_scenario(q, report, f"upcoming corner {name} step {initial_step}")
            settle_input(q, f"{name} step {initial_step}")
            q.input_entry(want)
            fixture = isolate_route(q, delivery, rt, route, f"{name}-step-{initial_step}")
            fixtures.append(fixture)
            q.fixture(cx, cy, old, initial_step)
            if q.val("PLAYER_WANT") != want or q.val("JOY_DIR") != want:
                raise AssertionError(f"{name}: mapped request was not retained")
            for partial in range(initial_step, 4):
                if partial != initial_step:
                    q.go("player_tick")
                if q.val("PLAYER_STEP") != partial:
                    raise AssertionError(f"{name}: step before old-axis advance is {q.val('PLAYER_STEP')}, expected {partial}")
                q.go("pt_done")
                sample = pose_sample(q)
                if partial < 3:
                    expected = [cx, cy, partial + 1,
                                center_fb(cx, cy) + DIR_STEP[old] * (partial + 1)]
                else:
                    expected = [nx, ny, 0, center_fb(nx, ny)]
                assert_pose(sample, expected, f"{name} old-axis step {partial}")
                if sample["direction"] != old or sample["want"] != want or sample["snap"] != 0:
                    raise AssertionError(f"{name}: changed direction/snap before next-center admission: {sample}")
            q.go("player_tick")
            q.go("pt_done")
            expected = [nx, ny, 1, center_fb(nx, ny) + DIR_STEP[want]]
            sample = pose_sample(q)
            assert_pose(sample, expected, f"{name} centered turn")
            if sample["direction"] != want or sample["face"] != want or sample["snap"] != 0:
                raise AssertionError(f"{name}: buffered turn was not admitted from center: {sample}")
            results.append({"case": name, "initial_step": initial_step,
                            "current": list(current), "next_center": list(next_cell),
                            "final_pose": sample["pose"], "direction": want})
    return results


def gate_snapshot(q, rt) -> dict[str, object]:
    state = q.phys(PAGE34 + 0x240, 1)[0]
    if q.ms.get("GATE_STATE") != 0xA240:
        raise AssertionError(f"GATE_STATE map address is {q.ms.get('GATE_STATE')!r}, expected $A240")
    logical_state = rt.r.read_bytes(q.c, 0xA240, 1)[0]
    if state != logical_state:
        raise AssertionError(f"GATE_STATE logical/physical mismatch: {logical_state} != {state}")
    return {"world_state": state, "anim_id": q.val("GATE_ANIM_ID"),
            "anim_style": q.val("GATE_ANIM_STYLE"),
            "compose_mode": q.val("GATE_COMPOSE_MODE"),
            "queue1": [q.val("RENDER_GATE_ID"), q.val("RENDER_GATE_MODE"),
                       q.val("RENDER_GATE_STYLE")],
            "queue2": [q.val("RENDER_GATE2_ID"), q.val("RENDER_GATE2_MODE"),
                       q.val("RENDER_GATE2_STYLE")],
            "fb_pending_context": q.val("FB_RENDER_PENDING"),
            "fb_commit_seq_context": int.from_bytes(q.low("FB_COMMIT_SEQ", 2), "big")}


def gate_purity(snapshot: dict[str, object]) -> tuple[object, ...]:
    return (snapshot["world_state"], snapshot["anim_id"], snapshot["anim_style"],
            snapshot["compose_mode"], tuple(snapshot["queue1"]), tuple(snapshot["queue2"]))


def test_upcoming_gate(q, delivery, fixtures, report, rt) -> dict[str, object]:
    begin_scenario(q, report, "upcoming gate steps 1-2-3 and centered passage")
    settle_input(q, "upcoming gate")
    q.input_entry(2)
    fixture = isolate_route(q, delivery, rt, {(3, 2), (4, 2), (4, 3), (4, 4)},
                            "upcoming-gate-0")
    fixtures.append(fixture)
    q.fixture(3, 2, 1, 1)
    if q.val("PLAYER_WANT") != 2 or q.val("JOY_DIR") != 2:
        raise AssertionError("real south input was not retained at upcoming gate")
    if q.val("FB_RENDER_PENDING"):
        raise AssertionError("gate fixture began with an uncommitted framebuffer")
    q.put(PAGE34 + 0x240, [0])
    for key in ("GATE_ANIM_ID", "GATE_ANIM_STYLE", "GATE_COMPOSE_MODE",
                "RENDER_GATE_ID", "RENDER_GATE_MODE", "RENDER_GATE_STYLE",
                "RENDER_GATE2_ID", "RENDER_GATE2_MODE", "RENDER_GATE2_STYLE"):
        q.dp(key, [0])
    initial = gate_snapshot(q, rt)
    if initial["world_state"] != 0:
        raise AssertionError(f"gate 0 test fixture did not start at state 0: {initial}")
    trace = []
    for partial in (1, 2, 3):
        if partial > 1:
            q.go("player_tick")
        if q.val("PLAYER_STEP") != partial:
            raise AssertionError(f"gate fixture step is {q.val('PLAYER_STEP')}, expected {partial}")
        before = gate_snapshot(q, rt)
        q.go("pt_done")
        current = gate_snapshot(q, rt)
        pose = pose_sample(q)
        if partial < 3:
            if gate_purity(current) != gate_purity(before):
                raise AssertionError(f"gate preview mutated world/render state at step {partial}: {before} -> {current}")
            expected = [3, 2, partial + 1, center_fb(3, 2) + partial + 1]
            assert_pose(pose, expected, f"gate old-axis step {partial}")
            if pose["direction"] != 1 or pose["snap"] != 0:
                raise AssertionError(f"gate preview did not retain eastward approach: {pose}")
        else:
            if current["world_state"] != 1 or current["anim_id"] != 1:
                raise AssertionError(f"gate state/action was not committed once at step 3: {current}")
            if current["anim_style"] != 0 or current["compose_mode"] != 0:
                raise AssertionError(f"gate commit style/compose differs from approved target: {current}")
            if current["queue1"] != [1, 0, 0] or current["queue2"] != [0, 0, 0]:
                raise AssertionError(f"gate redraw intent was not queued exactly once: {current}")
            if pose["pose"] != [4, 2, 0, center_fb(4, 2)] or pose["direction"] != 1:
                raise AssertionError(f"step-3 gate approach did not arrive at next center: {pose}")
        trace.append({"partial_step": partial, "before": before, "after": current, "player": pose})
    q.go("player_tick")
    q.go("pt_done")
    centered = pose_sample(q)
    if centered["pose"] != [4, 2, 1, center_fb(4, 2) + DIR_STEP[2]]:
        raise AssertionError(f"centered south passage through rotated gate was not admitted: {centered}")
    if centered["direction"] != 2 or centered["face"] != 2 or centered["snap"] != 0:
        raise AssertionError(f"centered south passage changed direction/snap unexpectedly: {centered}")
    if gate_snapshot(q, rt)["world_state"] != 1:
        raise AssertionError("centered south passage rotated gate a second time")
    return {"steps_1_2_3": trace, "centered_south": centered,
            "gate": [5, 3], "world_transition": "state 0 to 1 exactly once",
            "intent_is_not_display_commit": True}


def run() -> dict[str, object]:
    frozen = check_frozen_inputs()
    delivery, rt, legacy = load_shared_modules()
    q = rt.Run()
    report: dict[str, object] = {
        "ticket": "BUG-121",
        "step": "QA preparation; no production acceptance",
        "frozen_dependency_sha256": frozen,
        "deadlines": {"phase_seconds": 45, "marker_wait_seconds": 10},
        "timeout_meaning": "required observer boundary absent within its phase; no speed inference",
    }
    q.artifact_qualified = False
    q.current_scenario = "artifact delivery"
    def failure_context():
        context = {"scenario": q.current_scenario}
        if not q.artifact_qualified:
            return context
        try:
            context["pose"] = q.pose()
            context["player_step"] = q.val("PLAYER_STEP")
            context["player_want"] = q.val("PLAYER_WANT")
            context["player_direction"] = q.val("PLAYER_DIR")
            context["gate_state"] = q.phys(PAGE34 + 0x240, 1).hex()
        except Exception as context_error:
            context["capture_error"] = repr(context_error)
        return context
    q.qa_failure_context = failure_context
    try:
        report.update(record_source_and_artifacts())
        report["phase"] = "artifact delivery and byte qualification"
        report["artifact_delivery"] = delivery.wait_for_artifact_delivery(q, BUILD, True)
        q.artifact_qualified = True
        report["phase"] = "natural cold/start/full-entry"
        q.current_scenario = report["phase"]
        natural_identity = q.start()
        report["natural_start_identity"] = natural_identity
        report["natural_entry_samples"] = len(q.entry_traces[0]) if q.entry_traces else 0
        track_player_markers(q, rt, report)
        report["phase"] = "qualified fixture-table bytes"
        q.current_scenario = report["phase"]
        tables = qualified_tables(q, rt)
        report["fixture_table_sha256"] = {
            "maze_nav": digest(tables[0]), "maze_gate_owner": digest(tables[1]),
            "maze_gates": digest(tables[2])}
        report["natural_movement"] = test_natural_movement(q, tables, report)
        begin_scenario(q, report, "existing movement controls")
        settle_input(q, "existing movement controls")
        old_start = q.start
        q.start = lambda: natural_identity
        try:
            report["existing_movement_controls"] = legacy.test(q)
        finally:
            q.start = old_start
        fixtures: list[dict[str, object]] = []
        report["fixture_isolation"] = fixtures
        report["mapped_midcorridor_reversal"] = test_mapped_midcorridor_reversal(
            q, delivery, rt, fixtures, report)
        report["missing_no_exit_offsets"] = test_missing_no_exit_offsets(q, delivery, rt, fixtures, report)
        report["upcoming_corners"] = test_upcoming_corners(q, delivery, rt, tables, fixtures, report)
        report["upcoming_gate"] = test_upcoming_gate(q, delivery, fixtures, report, rt)
        report["phase"] = "complete"
        report["result"] = "PASS"
    except Exception as exc:
        delivery.attach_failure_evidence(exc, q)
        report["result"] = "FAIL"
        report["failure"] = repr(exc)
        report["qa_failure_evidence"] = getattr(exc, "qa_evidence", {})
        report["current_scenario"] = q.current_scenario
    finally:
        try:
            q.close()
        except Exception as close_error:
            report.setdefault("close_error", repr(close_error))
    return report


if __name__ == "__main__":
    result = {"result": "FAIL"}
    try:
        result = run()
    except Exception as exc:
        result.update({"failure": repr(exc)})
    target = SCRATCH / "receipt.json"
    target.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    if result.get("result") != "PASS":
        raise SystemExit(1)
